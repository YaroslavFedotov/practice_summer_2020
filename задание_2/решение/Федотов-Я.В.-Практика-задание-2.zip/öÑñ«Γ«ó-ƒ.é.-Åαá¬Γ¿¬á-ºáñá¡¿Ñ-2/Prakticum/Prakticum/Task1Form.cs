﻿using System;
using System.Windows.Forms;
using PrackticumCL;
namespace Prakticum
{
    public partial class Task1Form : Form
    {
        Task2 task2 = new Task2();
        public Task1Form()
        {
            InitializeComponent();
        }

        private void buttonResult_Click(object sender, EventArgs e)
        {
           try
           {

                task2 = new Task2(double.Parse(AtextBox.Text), textBoxInputNumber.Text);
                textBoxResult.Text = task2.ResultTaskFactors;

           }
           catch (Exception)
           {
               textBoxResult.Text = "incorrect number";
           }
        }

        private void Task1Form_Load(object sender, EventArgs e)
        {

        }
    }
}
