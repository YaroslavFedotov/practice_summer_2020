﻿using System;

namespace PrackticumCL
{
    public class Task2
    {
       /// <summary>
       /// Число результата задачи - свойство.
       /// </summary>
       public string ResultTaskFactors { get; set; }
       /// <summary>
       /// Стандартный конструктор класса Task2
       /// </summary>
       public Task2()
       {

       }
        /// <summary>
        /// Констурктор класса Task2
        /// </summary>
        /// <param name="ArrayNumber">На вход подается исходный массив.</param>
        /// <param name="a">На вход подается исходное число.</param>
        public Task2(double a, string ArrayNumber)
        {
            ComparisonFactors(a, ArrayNumber);
        }
        /// <summary>
        /// Метод, занимающийся проверкой делимости на 4 без остатка номера поданного на вход.
        /// </summary>
        /// <param name="ArrayNumber">На вход подается массив для вычисления минимума и максимума массва для сравнения с числом "a".</param>
        /// <param name="a">На вход подается исходное число для сравнения с минимумом массива.</param>
        private void
        ComparisonFactors(double a, string ArrayNumber)
        {
            ArrayNumber += " ";
            double ArrMax = 0;
            double ArrMin = 0;
            string baf = "";
            int step = 0;
            bool start = false;
            for (int i = 0; i  < ArrayNumber.Length; i++)
            {
                if  (ArrayNumber[i] == ' ')
                {
                    double temp = double.Parse(baf);
                    if (start == false)
                    {
                        ArrMax = temp;
                        ArrMin = temp;
                        start = true;
                        baf = "";
                        step++;
                    }
                    else
                    {
                        if (temp < ArrMin)
                            ArrMin = temp;
                        if (temp > ArrMax)
                            ArrMax = temp;
                        baf = "";
                        step++;
                    }
                }
                else
                {
                    baf += ArrayNumber[i];
                }
            }
            if (a < ArrMin)
            {
               for (int i = 0; i < step; i++)
               {
                    ResultTaskFactors += ArrMin + " ";
               }
            }
            else
            {
               for (int i = 0; i < step; i++)
               {
                    ResultTaskFactors += ArrMax + " ";
               }
            }
        }
    }
}

